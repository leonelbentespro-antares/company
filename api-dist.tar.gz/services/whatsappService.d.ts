export declare const sessions: Map<string, {
    tenantId: string;
    token: string;
    status: string;
}>;
export declare const qrCodes: Map<string, string>;
/**
 * Faz requisições HTTP para a uazapiGO V2.
 * IMPORTANTE: Esta conta UAZAPI usa AdminToken em TODOS os endpoints.
 * O token de instância individual não funciona neste plano.
 */
export declare function uazapiFetch(endpoint: string, method?: string, body?: any, _instanceToken?: string): Promise<any>;
/**
 * Inicia ou retoma uma sessão WhatsApp para o tenant.
 * Fluxo V2: /instance/init -> /webhook -> /instance/connect
 */
export declare function startWhatsAppSession(tenantId: string, phone?: string): Promise<{
    tenantId: string;
    token: string;
    status: string;
}>;
/**
 * Consulta o status atual da instância.
 */
export declare function getInstanceStatus(instanceToken: string): Promise<any>;
/**
 * Envia mensagem de texto via POST /send/text.
 */
export declare function sendTextMessage(instanceToken: string, number: string, text: string): Promise<any>;
/**
 * Envia mídia.
 */
export declare function sendMediaMessage(instanceToken: string, number: string, mediaUrl: string, caption?: string, mediaType?: string): Promise<any>;
export declare function getSession(tenantId: string): {
    tenantId: string;
    token: string;
    status: string;
} | undefined;
export declare function getQR(tenantId: string): string | undefined;
/**
 * Desconecta a instância.
 */
export declare function logoutSession(tenantId: string): Promise<void>;
/**
 * Handle incoming connection events from webhooks to persist the session via Supabase directly.
 */
export declare function handleConnectionEvent(tenantId: string, status: string, phone?: string): Promise<void>;
//# sourceMappingURL=whatsappService.d.ts.map