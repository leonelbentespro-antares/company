export declare function processIncomingMessage(payload: any, eventSource: 'uazapi' | 'notificame' | 'meta'): Promise<void>;
//# sourceMappingURL=messageProcessor.d.ts.map