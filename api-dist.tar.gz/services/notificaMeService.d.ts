/**
 * NotificaMe Hub API Service
 * Base URL: https://api.notificame.com.br/v1/
 */
export declare function notificaMeFetch(endpoint: string, method: string, apiToken: string, body?: any): Promise<any>;
/**
 * Envia mensagem de texto via NotificaMe Hub
 */
export declare function sendNotificaMeText(apiToken: string, channelId: string, to: string, text: string): Promise<any>;
/**
 * Envia mensagem de mídia via NotificaMe Hub
 */
export declare function sendNotificaMeMedia(apiToken: string, channelId: string, to: string, mediaUrl: string, caption?: string, fileMimeType?: string): Promise<any>;
/**
 * Registra um webhook para o canal
 */
export declare function subscribeNotificaMeWebhook(apiToken: string, channelId: string, webhookUrl: string): Promise<any>;
/**
 * Lista os canais/dispositivos disponíveis (opcional para validação)
 */
export declare function listNotificaMeChannels(apiToken: string): Promise<any>;
//# sourceMappingURL=notificaMeService.d.ts.map