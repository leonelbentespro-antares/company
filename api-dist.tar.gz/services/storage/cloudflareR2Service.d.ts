/**
 * Faz o upload de um arquivo para o Cloudflare R2
 * @param fileBuffer O buffer do arquivo a ser enviado
 * @param fileName O nome original do arquivo
 * @param tenantId O ID do cliente (para isolar os arquivos por pasta)
 * @param mimeType O tipo do arquivo (ex: application/pdf, image/jpeg)
 * @returns A URL pública ou caminho do arquivo salvo
 */
export declare function uploadFileToR2(fileBuffer: Buffer, fileName: string, tenantId: string, mimeType: string): Promise<string>;
/**
 * Gera uma URL temporária (Presigned URL) para download ou visualização segura do arquivo
 * @param objectKey O caminho do arquivo salvo no R2 (retornado no upload)
 * @param expiresIn Tempo em segundos para a URL expirar (padrão: 1 hora)
 */
export declare function getSecureFileUrl(objectKey: string, expiresIn?: number): Promise<string>;
/**
 * Deleta um arquivo do storage
 * @param objectKey O caminho do arquivo no R2
 */
export declare function deleteFileFromR2(objectKey: string): Promise<boolean>;
/**
 * Faz o upload de um arquivo para o Cloudflare R2 e retorna uma Presigned URL de 7 dias.
 * Utilizada para mídia de chat (imagens, vídeos, áudios) que precisam ser acessíveis pelo frontend.
 */
export declare function uploadMediaToR2(fileBuffer: Buffer, fileName: string, tenantId: string, mimeType: string): Promise<string>;
//# sourceMappingURL=cloudflareR2Service.d.ts.map