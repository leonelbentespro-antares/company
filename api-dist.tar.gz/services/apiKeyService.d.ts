/**
 * Serviço para gerenciamento de chaves de API (Access Tokens)
 */
export interface ApiKey {
    id: string;
    tenant_id: string;
    name: string;
    key_preview: string;
    created_at: string;
    last_used_at?: string;
}
/**
 * Gera uma nova chave de API segura
 * Formato: lh_live_[32 chars random hex]
 */
export declare function generateSecureKey(): string;
/**
 * Gera um hash SHA-256 de uma chave
 */
export declare function hashKey(key: string): string;
/**
 * Lista todas as chaves de um tenant
 */
export declare function listApiKeys(tenantId: string): Promise<ApiKey[]>;
/**
 * Cria uma nova chave para o tenant
 */
export declare function createApiKey(tenantId: string, name: string): Promise<{
    id: string;
    rawKey: string;
}>;
/**
 * Remove uma chave de API
 */
export declare function deleteApiKey(id: string, tenantId: string): Promise<void>;
/**
 * Valida uma chave de API e retorna o tenant_id associado
 */
export declare function validateApiKey(rawKey: string): Promise<string | null>;
//# sourceMappingURL=apiKeyService.d.ts.map