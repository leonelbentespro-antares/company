export declare const redisConnection: any;
//# sourceMappingURL=redis.d.ts.map