export declare const documentGenerationQueue: any;
//# sourceMappingURL=documents.d.ts.map