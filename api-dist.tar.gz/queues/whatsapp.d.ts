export declare const whatsappIncomingQueue: any;
export declare const whatsappOutgoingQueue: any;
//# sourceMappingURL=whatsapp.d.ts.map