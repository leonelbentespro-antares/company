export declare const apiKeysRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=apiKeys.d.ts.map