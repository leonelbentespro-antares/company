import type { Request, Response, NextFunction } from 'express';
/**
 * Middleware para autenticar requisições usando x-api-key
 * Injeta o tenantId no objeto request
 */
export declare function apiKeyAuth(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=apiKeyAuth.d.ts.map