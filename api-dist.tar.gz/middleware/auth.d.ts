import type { Request, Response, NextFunction } from 'express';
/**
 * Middleware de Autenticação Universal
 * Aceita:
 * 1. Header 'x-api-key': Para integrações externas e webhooks.
 * 2. Header 'Authorization: Bearer <token>': Para o frontend (Supabase JWT).
 */
export declare function authMiddleware(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=auth.d.ts.map