/**
 * ============================================================
 * LEXHUB SAAS — API GATEWAY (CORE SERVICE)
 * Versão Segura com Proteção Multi-Camada
 * ============================================================
 */
export {};
//# sourceMappingURL=index.d.ts.map